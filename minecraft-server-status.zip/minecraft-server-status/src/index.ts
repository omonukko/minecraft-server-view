import { consola } from 'consola';
import { status, statusBedrock } from 'minecraft-server-util';
import readline from 'readline';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function getJavaServerInfo(ip: string, port: number) {
    try {
        consola.info('Getting Server Status...')
        const response = await status(ip, port, { timeout: 5000 });

        console.clear();
        consola.success(`Get Server Status for ${ip}:${port}:`);
        consola.success(`Motd: ${response.motd.clean}`);
        consola.success(`PlayerCount: ${response.players.online}/${response.players.max}`);
        consola.success(`Version:${response.version.name}`)
        consola.success(`Ping: ${response.roundTripLatency}ms`);
    } catch (error) {
        consola.error('Failed Status Get', error);
    }
}

async function getBedrockServerInfo(ip: string, port: number) {
    try {
        consola.info('Getting Server Status...')
        const response = await statusBedrock(ip, port, { timeout: 5000 });

        console.clear();
        consola.success(`Get Server Status for ${ip}:${port}:`);
        consola.success('Bedrock Edition Infos:');
        consola.success(`Motd: ${response.motd.clean}`);
        consola.success(`Version:${response.version.name}`)
        consola.success(`Players: ${response.players.online}/${response.players.max}`);
    } catch (error) {
        consola.error('Failed ', error);
    }
}

rl.question('Minecraft Version Select Plz: (java/bedrock): ', (version) => {
    rl.question('Enter the ipaddress: ', (ip) => {
        rl.question('Enter the port: ', (portStr) => {
            const port = parseInt(portStr);

            if (version.toLowerCase() === 'java') {
                setInterval(() => {
                    getJavaServerInfo(ip, port);
                }, 1000);
            } else if (version.toLowerCase() === 'bedrock') {
                setInterval(() => {
                    getBedrockServerInfo(ip, port);
                }, 1000);
            } else {
                consola.error('無効なバージョンが選択されました。 "java" か "bedrock" を入力してください。');
                rl.close();
            }
        });
    });
});
