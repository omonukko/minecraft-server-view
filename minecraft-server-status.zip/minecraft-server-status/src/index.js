"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const consola_1 = require("consola");
const minecraft_server_util_1 = require("minecraft-server-util");
const readline_1 = __importDefault(require("readline"));
const rl = readline_1.default.createInterface({
    input: process.stdin,
    output: process.stdout
});
function getJavaServerInfo(ip, port) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            consola_1.consola.info('Getting Server Status...');
            const response = yield (0, minecraft_server_util_1.status)(ip, port, { timeout: 5000 });
            console.clear();
            consola_1.consola.success(`Get Server Status for ${ip}:${port}:`);
            consola_1.consola.success(`Motd: ${response.motd.clean}`);
            consola_1.consola.success(`PlayerCount: ${response.players.online}/${response.players.max}`);
            consola_1.consola.success(`Version:${response.version.name}`);
            consola_1.consola.success(`Ping: ${response.roundTripLatency}ms`);
        }
        catch (error) {
            consola_1.consola.error('Failed Status Get', error);
        }
    });
}
function getBedrockServerInfo(ip, port) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            consola_1.consola.info('Getting Server Status...');
            const response = yield (0, minecraft_server_util_1.statusBedrock)(ip, port, { timeout: 5000 });
            console.clear();
            consola_1.consola.success(`Get Server Status for ${ip}:${port}:`);
            consola_1.consola.success('Bedrock Edition Infos:');
            consola_1.consola.success(`Motd: ${response.motd.clean}`);
            consola_1.consola.success(`Version:${response.version.name}`);
            consola_1.consola.success(`Players: ${response.players.online}/${response.players.max}`);
        }
        catch (error) {
            consola_1.consola.error('Failed ', error);
        }
    });
}
rl.question('Minecraft Version Select Plz: (java/bedrock): ', (version) => {
    rl.question('Enter the ipaddress: ', (ip) => {
        rl.question('Enter the port: ', (portStr) => {
            const port = parseInt(portStr);
            if (version.toLowerCase() === 'java') {
                setInterval(() => {
                    getJavaServerInfo(ip, port);
                }, 1000);
            }
            else if (version.toLowerCase() === 'bedrock') {
                setInterval(() => {
                    getBedrockServerInfo(ip, port);
                }, 1000);
            }
            else {
                consola_1.consola.error('無効なバージョンが選択されました。 "java" か "bedrock" を入力してください。');
                rl.close();
            }
        });
    });
});
